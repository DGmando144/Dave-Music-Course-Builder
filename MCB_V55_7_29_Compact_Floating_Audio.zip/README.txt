V55.7.29: Floating audio toolbar only — compact 32x30 buttons, 23px icons, 8px captions, 64px speed; retains desktop, mobile and playback functionality from V55.7.28. Replace index.html only.
